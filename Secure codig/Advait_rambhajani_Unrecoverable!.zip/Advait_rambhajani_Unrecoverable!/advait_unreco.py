import pathlib, os
from typing import Union, AnyStr
def secure_delete(path: Union[AnyStr, pathlib.Path], passes: int =3) -> None:
  
    with open(path, "ba+", buffering=0) as delfile:
        length: int = delfile.tell()
    delfile.close()
    with open(path, "br+", buffering=0) as delfile:
        for i in range(passes):
            delfile.seek(0,0)
            delfile.write(os.urandom(length))
        delfile.seek(0)
        for x in range(length):
            delfile.write(b'\x00')
    os.remove(path)

if __name__ == '__main__':
    path = input('Enter the file path to be deleted: ')
    if os.path.isfile(path.strip(' ').strip('\n')):
        secure_delete(path)
        print('Securely Deleted:', path)
    else:
        print('The given file does not exists in the system')