<?php
function sanitize_input($input)
{
    $sanitized_input = filter_var(filter_var(filter_var($input, FILTER_SANITIZE_STRING), FILTER_SANITIZE_ENCODED), FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    return $sanitized_input;
}

function sanitize_email($input)
{
    $sanitized_input = filter_var($input, FILTER_SANITIZE_EMAIL);
    return $sanitized_input;
}

