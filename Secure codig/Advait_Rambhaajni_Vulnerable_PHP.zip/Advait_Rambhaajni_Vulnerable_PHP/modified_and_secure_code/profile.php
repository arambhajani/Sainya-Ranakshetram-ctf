<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

    <title>Secure Coding | Secured</title>
</head>
<?php
include 'connection.php';
session_start();

# Adding SQLi Protection here
# Creating prepared statement and binding id to it
$fetch_user_with_id_query = $connection->prepare("SELECT username, email FROM users where id=?");
$fetch_user_with_id_query->bind_param("s", $id);

$id = $_SESSION['id'];

$fetch_query_result = $fetch_user_with_id_query->execute();
$fetch_user_with_id_query->store_result();
$fetch_user_with_id_query->bind_result($user_name, $user_email);
$fetch_user_with_id_query->fetch();
$fetch_user_with_id_query->close();
?>

<body>
    <div class="container py-2">
        <div class="jumbotron">
            <h1>User Profile</h1>
            <form method="POST" action="profile.php">
                <div class="form-group">
                    <label>Username:</label>
                    <input type="text" class="form-control" name="username" value="<?php echo $user_name; ?>" />
                    <div>
                        <div class="form-group">
                            <label>Email:</label>
                            <input type="text" class="form-control" name="email" value="<?php echo $user_email; ?>" />
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success" name="submit">Update</button>
                            <button name="logout" class="btn btn-danger">Log out</button>
                        </div>
            </form>
            <div>
                <div>
                    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
                    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
                    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>
<?php
include "sanitize.php";
if (isset($_POST['submit'])) {

    # Preventing SQLi by using prepared statment
    $user_data_update_query = $connection->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
    $user_data_update_query->bind_param("sss", $username, $email, $id);

    # Preventing XSS by passing the userinput through sanitization function
    $username = sanitize_input($_POST['username']);
    $email = sanitize_email($_POST['email']);
    $id = $_SESSION['id'];

    $update_query_result = $user_data_update_query->execute();
    $user_data_update_query->store_result();
    $user_data_update_query->close();
    header("Location: index.php");
}
if (isset($_POST['logout'])) {
    unset($_SESSION['id']);
    session_destroy();
    header("Location: index.php");
}
?>